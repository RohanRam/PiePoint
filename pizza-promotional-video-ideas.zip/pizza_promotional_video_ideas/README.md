# Pizza Promotional Video Ideas

A small, documentation-only idea pack for brainstorming short promotional videos using the included pizza illustrations.

> This folder is standalone creative documentation. It does not change application code, dependencies, configuration, or build behavior.

## Included files

- `video-ideas.md` — concepts, hooks, shot lists, and sample captions.
- `storyboard.html` — a local, static storyboard preview using the included images.
- `assets/` — copies of the supplied pizza images.

## Quick start

Open `storyboard.html` in a browser, or read `video-ideas.md` for the concepts.

## Safe repository addition

Copy this entire folder into the root of your existing repository. It adds only documentation and image assets; it does not modify existing files. Review the diff before committing.

## Suggested commit message

`docs: add pizza promotional video concepts`

## Attribution note

The images were supplied for this idea pack. Confirm you have the right to publish them in the target repository before pushing.
